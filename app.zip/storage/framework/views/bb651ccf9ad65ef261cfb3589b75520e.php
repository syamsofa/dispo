<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
    </head>
    <body>
        Layanan Dispo Surat
    </body>
</html>
<?php /**PATH C:\2025\aplikasi\dispo\resources\views/welcome.blade.php ENDPATH**/ ?>